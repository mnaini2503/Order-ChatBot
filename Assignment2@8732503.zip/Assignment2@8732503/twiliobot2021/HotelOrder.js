const Order = require("./Order");

const OrderState = Object.freeze({
    WELCOMING:   Symbol("welcoming"),
    SERVE:   Symbol("serve"),
    ADDONS:   Symbol("addons"),
    DRINKS:  Symbol("drinks"),
    ONIONRINGS: Symbol("onionrings"),
    DISHPRICE: Symbol("dishprice"),
    SERVEPRICE: Symbol("serveprice"),
    TOTALPRICE: Symbol("totalprice"),
    ADDONSPRICE :Symbol("addonsprice"),
    ONIONRINGSPRICE: Symbol("onionringsprice"),
    DRINKSPRICE: Symbol("drinksprice"),
    PAYMENT: Symbol("payment")
});

module.exports = class HotelOrder extends Order{
    constructor(sNumber, sUrl){
        super(sNumber, sUrl);
        this.stateCur = OrderState.WELCOMING;
        this.sSERVE = "";
        this.sMenu = "";
        this.sADDONS = "";
        this.sDrinks = "";
        this.sONIONRINGS = "";
        this.sItem = "";
        this.sDISHPRICE = "";
        this.sSERVEprice = "";
        this.totalprice = "";
        this.sADDONSprice = "";
        this.sONIONRINGSprice = "";
        this.sDrinksprice = "";
    }
    handleInput(sInput){
        let aReturn = [];
        switch(this.stateCur){
          case OrderState.WELCOMING:
            //this.orderItems.push(sInput)
            aReturn.push("Welcome to Manish's Hotel");
            aReturn.push("What food would you like to order?");
            aReturn.push("Biryani" + "=" + "$25; " + "Butter Chicken Curry" + "=" + "$15");
            this.stateCur = OrderState.MENU;
            break;
          case OrderState.MENU:
            if (sInput.toLowerCase() == "biryani"){
                this.sItem = "Biryani"
                this.sDISHPRICE = 25
                this.totalprice = this.sDISHPRICE
                console.log(this.totalprice);
                aReturn.push(`How many SERVE's? of ${sInput} l or 2 or 3 would you like?`);
                this.stateCur = OrderState.SERVE

            }
            else if(sInput.toLowerCase() == "butterchickencurry" || sInput.toLowerCase() == "chickencurry" || sInput.toLowerCase() == "butterchicken" || sInput.toLowerCase() == "chicken"){
                this.sItem = "ButterChickenCurry"
                this.sDISHPRICE = 15
                this.totalprice = this.sDISHPRICE
                console.log(this.totalprice);
                aReturn.push(`How many SERVE's? of ${sInput} l or 2 or 3 would you like?`);
                this.stateCur = OrderState.SERVE
            }
            else{
                aReturn.push("Please enter a valid dish");
            }
            break;
          case OrderState.SERVE:
            if (sInput == 1 || sInput == 2 || sInput ==3){
            this.stateCur = OrderState.ADDONS
            this.sSERVE = sInput;
            this.sSERVEprice = (sInput - 1) * this.sDISHPRICE
            this.totalprice = this.totalprice + this.sSERVEprice
            console.log(this.totalprice);
            aReturn.push("What addons would you like?");
            aReturn.push("Salad" + "=" + "$2");
            aReturn.push("Raita" + "=" + "$5");
            }
            else {
              aReturn.push("Please enter a valid serve Quantity: 1 - 2 - 3");
            }
            break;
            case OrderState.ADDONS:
              this.stateCur = OrderState.ONIONRINGS
              this.sADDONS = sInput;
              aReturn.push("Would you like OnionRings yes($5) or no($0) with that?");
              if (sInput.toLowerCase() == "raita"){
                  this.sADDONSprice = 5
              }
              else if (sInput.toLowerCase() == "salad"){
                  this.sADDONSprice = 2
              }
              else {
                this.sADDONSprice = 0
                this.sADDONS = NULL
              }
              this.totalprice = this.totalprice + this.sADDONSprice
              console.log(this.totalprice);
              break;
          case OrderState.ONIONRINGS:
            this.stateCur = OrderState.DRINKS
            if(sInput.toLowerCase() != "no"){
                this.sONIONRINGS = sInput;
                this.sONIONRINGSprice = 5
                this.totalprice = this.totalprice + this.sONIONRINGSprice
                console.log(this.totalprice);
                aReturn.push("Would you like drinks yes($2) or no($0) with that?");
                break;
            }
            else{
                this.sONIONRINGSprice = 0
                this.totalprice = this.totalprice + this.sONIONRINGSprice

            }                
          case OrderState.DRINKS:
            if(sInput.toLowerCase() != "no"){
                this.sDrinks = sInput;
                this.sDrinksprice = 2
                this.totalprice = this.totalprice + this.sDrinksprice
                this.nOrder = this.totalprice
                console.log(this.totalprice);
            
            }
            else{
                this.sDrinksprice = 0
                this.totalprice = this.totalprice + this.sDrinksprice
                this.nOrder = this.totalprice

            }
            aReturn.push(`Thankyou for your order of  ${this.sSERVE} ${this.sItem} with ${this.sADDONS}`);
            if(this.sDrinks){
                aReturn.push(`Drinks ${this.sDrinks}`);
            }
            if(this.sONIONRINGS){
                aReturn.push(`ONIONRINGS ${this.sONIONRINGS}`);
            }
            aReturn.push(`Please pay for your order here`);
            aReturn.push(`${this.sUrl}/payment/${this.sNumber}/`);
            break;
          case OrderState.PAYMENT:
                console.log(sInput);
                this.isDone(true);
                let d = new Date();
                d.setMinutes(d.getMinutes() + 30);
                aReturn.push(`Your order will be delivered at ${d.toTimeString()}`);
                break;
        }
        return aReturn;
    }
    renderForm(){
      // your client id should be kept private
      const sClientID = process.env.SB_CLIENT_ID || 'put your client id here for testing ... Make sure that you delete it before committing'
      return(`
      <!DOCTYPE html>
  
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- Ensures optimal rendering on mobile devices. -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge" /> <!-- Optimal Internet Explorer compatibility -->
      </head>
      
      <body>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script
          src="https://www.paypal.com/sdk/js?client-id=${sClientID}"> // Required. Replace SB_CLIENT_ID with your sandbox client ID.
        </script>
        Thank you ${this.sNumber} for your order of $${this.nOrder}.
        <div id="paypal-button-container"></div>
  
        <script>
          paypal.Buttons({
              createOrder: function(data, actions) {
                // This function sets up the details of the transaction, including the amount and line item details.
                return actions.order.create({
                  purchase_units: [{
                    amount: {
                      value: '${this.nOrder}'
                    }
                  }]
                });
              }, 
              onApprove: function(data, actions) {
                // This function captures the funds from the transaction.
                return actions.order.capture().then(function(details) {
                  // This function shows a transaction success message to your buyer.
                  $.post(".", details, ()=>{
                    window.open("", "_self");
                    window.close(); 
                  });
                });
              }
          
            }).render('#paypal-button-container');
          // This function displays Smart Payment Buttons on your web page.
        </script>
      
      </body>
          
      `);
  
    }
}